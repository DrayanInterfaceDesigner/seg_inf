from struct import pack
import myscapyLib as IDS

#-------------------------------------------------------------------------
# REGRA 1: DETECTAR ICMP FLOOD UMA FONTE (PING OF DEATH)
# -- uma fonte está enviando pacotes com uma taxa muito alta

def detectaPoD(pacotes, limite):
    # A) filtre pacotes do tipo ICMP   
    pacotes = IDS.filtraTipo(pacotes, IDS.TIPO['icmp'])
    # B) crie o dicionário com o número de pacotes por origem
    origens = IDS.contaIPOrigem(pacotes)
    # C) selecione os IPs cujo número de pacotes enviados excede o valor limite
    resultado = []
    for ip,quant in origens.items():
        if(quant > limite):
            resultado.append(ip)
    # D) gere uma mensagem de alerta para cada IP na seleção indicado que estão fazendo o ataque    
    for ip in resultado:
        IDS.alerta(f'O IP {ip} esta fazendo ICMP Flood')
    if len(resultado) == 0:
        print('PoD não foi detectado ou eu não fiz o exercicio')
#-------------------------------------------------------------------------    
# REGRA 2: DETECTAR ICMP FLOOD DE VARIAS FONTES (Distributed PING OF DEATH)
# -- um alvo está recebendo ICMP com uma taxa muito alta

def detectaDPoD(pacotes, limite):
    # A) filtre pacotes do tipo ICMP  
    packages = IDS.filtraTipo(pacotes, IDS.TIPO['icmp'])
    # B) crie o dicionário com o número de pacotes por destino 
    packages_per_destination = IDS.contaIPDestino(packages)
    # C) selecione os IPs cujo número de pacotes recebidos excede o valor limite
    resultado = []
    for dest, pckgs in packages_per_destination.items():
        if(pckgs > limite):
            resultado.append(dest)
    # D) gere uma mensagem de alerta para indicando quem está sendo atacado    
    for ip in resultado:
        IDS.alerta(f'O IP {ip} esta sendo ATACADO por ICMP Flood (DISTRIBUIDO)')
    if len(resultado) == 0:
        print('DPoD não foi detectado ou eu não fiz o exercicio')

#-------------------------------------------------------------------------
# REGRA 3: DETECTAR SYN FLOOD PELA ORIGEM OU DESTINO
# -- uma fonte está enviando pacotes SYN com uma taxa muito alta
# -- uma destino está rebendo pacotes SYN com uma taxa muito alta

def detectaSYNFlood(pacotes, limite):
    # A) filtre pacotes pelo flag S do TCP
    packages = IDS.filtraTCP(pacotes, 'S')
    # B) crie um dicionário com o número de pacotes por origem
    packages_per_origin = IDS.contaIPOrigem(packages)
    # C) selecione os IPs cujo número de pacotes enviados excede o valor limite
    resultado = []
    for ip, sent in packages_per_origin.items():
        if(sent > limite):
            resultado.append(ip)
    # D) gere uma mensagem de alerta para cada IP na seleção indicado que estão fazendo o ataque    
    for ip in resultado:
        IDS.alerta(f'O IP {ip} esta fazendo SYN Flood')
    # E) crie o dicionário com o número de pacotes por destino
    packages_per_destination = IDS.contaIPDestino(packages)
    # F) selecione os IPs cujo número de pacotes recebidos excede o valor limite
    resultado = []
    for ip, sent in packages_per_destination.items():
        if(sent > limite):
            resultado.append(ip)
    # G) gere uma mensagem de alerta para indicando quem está sendo atacado 
    for ip in resultado:
        IDS.alerta(f'O IP {ip} esta sendo atacado SYN Flood')
    if len(resultado) == 0:
        print('SYN FLOOD não foi detectado ou eu não fiz o exercicio')
#-------------------------------------------------------------------------
# REGRA 4: DETECTAR PORT SCAN 
# -- uma fonte está enviando pacotes para diversas portas

def detectaPSCAN(pacotes, limite):
    # A) filtre pacotes pelo flag S do TCP
    packages = IDS.filtraTCP(pacotes, 'S')
    # B) crie um dicionário com a chave IP de origem e valor do conjunto de portas de destino
    origins = {}
    for p in packages:
        ip = str(p[IDS.TIPO['ip']].src)
        port = int(p[IDS.TIPO['tcp']].dport)
        if ip in origins:
            origins[ip].add(port)
        else:
            origins[ip] = {port}
    # C) selecione os IPs cujo número de portas endereçadas excede o valor limite
    resultado = []
    for _ip, port in origins.items():
        if len(port) > limite:
            resultado.append(_ip)

        # _ports_amount = []
        # for port in range(ports, 1):
        #     if(ports[port-1] == ports[port]+1):
        #         _ports_amount.append(port)
        # if ports > limite:
        #     resultado.append(_ip)
            

    # D) gere uma mensagem de alerta para cada IP na seleção indicado que estão fazendo o ataque 
    for ip in resultado:
        IDS.alerta(f'O IP {ip} esta fazendo PORT SCAN')
    if len(resultado) == 0:
        print('PORT SCAN não foi detectado ou eu não fiz o exercicio')
        
#-------------------------------------------------------------------------
# REGRA 5: DETECTAR ATAQUE SYN ACK -- SMURF
# -- estão chegando pacotes SA de origens para nunca foi enviando S

def detectaSYNACK(pacotes, limite):
    # A) lista_SA = filtre pacotes pelo flag SA do TCP e crie um conjunto com os IPs de destino
    sa_packages = IDS.filtraTCP(pacotes, 'SA')
    sa_list = set(IDS.contaIPDestino(sa_packages).keys())

    # B) lista_A = filtre pacotes pelos flags S do TCP e crie um conjunto com os IPs de origem
    s_packages = IDS.filtraTCP(pacotes, 'S')
    s_list = set(IDS.contaIPOrigem(sa_packages).keys())

    # C) Calcule o complemento da lista_SA e lista_A (lista_SA - lista_A)
    
    resultado = sa_list - s_list
    # D) gere uma mensagem de alerta para cada IP na seleção indicado que estão fazendo o ataque 
    for ip in resultado:
        IDS.alerta(f'O IP {ip} esta sendo atacado por SYN ACK')
    if len(resultado) == 0:
        print('SYN ACK não foi detectado ou eu não fiz o exercício')

#-------------------------------------------------------------------------
if __name__ == '__main__':

    pacotes = IDS.carregaPacotes('desafio.pcap') 
    #IDS.mostraPacotes(pacotes, count=10)

    detectaPoD(pacotes, limite=10)
    detectaDPoD(pacotes, limite=10)
    detectaSYNFlood(pacotes, limite=10)
    detectaPSCAN(pacotes, limite=10)
    detectaSYNACK(pacotes, limite=10)





    